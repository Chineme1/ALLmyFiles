#include <iostream>

int main()
{
	std::cout<<"Hello ECS36B from 74645"<< std::endl;
}

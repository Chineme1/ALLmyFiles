#include <iostream>
//Chineme Uba
//916274645
#include "Angle.h"



		Angle::Angle(void) {theta= 30;}
		void Angle::change(int dt) {theta+=dt; if(theta>120){theta=120;}else if(theta<-60){theta=-60;}else{ theta=theta;}}
		void Angle::print(void){std::cout<<"angle: "<< theta<<std::endl;}
		int Angle::get(void){return theta;}

		int theta;
		void Angle::set(int t) {t = theta;}


